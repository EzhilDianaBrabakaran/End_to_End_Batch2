export class PaymentHistory{
    paymentId:number;
    userId:number;
    skillId:number;
    paymentAmount:string;
}
   