export class Payments{
    mentorPaymentId:number;
     skillId:number;
     mentorId:number;
     slot1:string;
     slot2:string;
     slot3:string;
     slot4:string;
}
    