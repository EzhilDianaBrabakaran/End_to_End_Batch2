export class Admin{
    name:string;
    email:string
    password:string;
    contact:string;
    status:string;
    role:string='admin';
 }