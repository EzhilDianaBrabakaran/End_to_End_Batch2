export class Skills{
    skillId:number;
    skillName:string;
    baseAmount:string;
 }
 