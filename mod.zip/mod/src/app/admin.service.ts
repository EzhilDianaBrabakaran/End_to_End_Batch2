import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { PaymentHistory } from './model/PaymentHistory';
import { Payments } from './model/Payments';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  private baseUrl = 'http://localhost:8254/api';
  private _email=new BehaviorSubject<String>(this._email);
  _email$=this._email.asObservable();
  

  constructor(private http: HttpClient) { }
  createAdmin(admin: Object): Observable<Object> {
    console.log(admin)
    return this.http.post(`${this.baseUrl}` + `/adminDetails`, admin);
  }
  savePaymentToMentor(payment: Object): Observable<Object> {
    console.log(payment);
    return this.http.post(`${this.baseUrl}`+'/payment',payment);
  }
  getPayment() {
    return this.http.get<PaymentHistory[]>(`${this.baseUrl}`+'/paymentHistoryList');
  }
  getPaymentHistoryId(selectedId:number): Observable<Object>{
    return this.http.get<PaymentHistory[]>(`${this.baseUrl}/paymentHistoryId/${selectedId}`);
  }
  addSkill(skill: Object): Observable<Object> {
    console.log(skill);
    return this.http.post(`${this.baseUrl}`+'/addSkill',skill);
  }
  getPaymentDetails() {
    return this.http.get<Payments[]>(`${this.baseUrl}`+'/paymentHistoryList');
  }
  setEmail(email:string)
  {
    this._email.next(email);
  }
}
