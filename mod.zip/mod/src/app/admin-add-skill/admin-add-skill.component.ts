import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { Skills } from '../model/Skills';

@Component({
  selector: 'app-admin-add-skill',
  templateUrl: './admin-add-skill.component.html',
  styleUrls: ['./admin-add-skill.component.css']
})
export class AdminAddSkillComponent implements OnInit {

  skill:Skills =new Skills();
  constructor(private adminService :AdminService) { }

  ngOnInit() {
  }
  addSkill(){
    console.log(this.skill);
    this.adminService.addSkill(this.skill)
    .subscribe(data => console.log(data), error => console.log(error));
    
  }
  onSubmit() {
  
    this.addSkill();
  }
}
