import { Component, OnInit } from '@angular/core';
import { PaymentHistory } from '../model/PaymentHistory';
import { Payments } from '../model/Payments';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminService } from '../admin.service';

@Component({
  selector: 'app-payment-forms',
  templateUrl: './payment-forms.component.html',
  styleUrls: ['./payment-forms.component.css']
})
export class PaymentFormsComponent implements OnInit {

  private paymentForm : PaymentHistory[];
 payment:Payments=new Payments();
  skillId:number;
  mentorPaymentId:number;
 selectedId:number
 
  activatedRoute: any;
  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private adminService: AdminService
  ) {}

  ngOnInit() {
    this.route.params.subscribe( params => 
      this.selectedId=+params.id );
    this.getPaymentId(this.selectedId);
  }

  getPaymentId(selectedId){
    
    this.adminService.getPaymentHistoryId(this.selectedId)
    .subscribe((res : any[])=>{
      console.log(res);
      this.paymentForm= res;
      this.payment.skillId=res[0].skillId;
      this.payment.mentorPaymentId=res[0].paymentId;
      })
  
     
       
  }
  onSubmit() {  
    console.log(this.payment)
    console.log(this.payment.mentorPaymentId)
    this.adminService.savePaymentToMentor(this.payment). subscribe(data => console.log(data), error => console.log(error));
  }  

}


