import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private baseUrl = 'http://localhost:8254/api';
private _email=new BehaviorSubject<String>(this._email);
_email$=this._email.asObservable();
  constructor(private http: HttpClient) { }
  setEmail(email:string)
  {
    this._email.next(email);
  }
  getMentorSkill(): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}`+'/user/trainingsAvailable');
  }
}
