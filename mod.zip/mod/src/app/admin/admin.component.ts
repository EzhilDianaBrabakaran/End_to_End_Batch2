import { Component, OnInit, Input } from '@angular/core';
import { Observable } from 'rxjs';
import { Login } from '../model/login';
import { LoginService } from '../service/login.service';
import { MentorService } from '../mentor.service';
import { AdminService } from '../admin.service';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {
  private admin: Login[];
  login:Login=new Login();
  email:string;
 
  constructor(private loginService: LoginService,private adminService: AdminService) { }

  ngOnInit() {
    this.adminService._email$.subscribe(message => this.email=message);
  }
  
    
    
}


