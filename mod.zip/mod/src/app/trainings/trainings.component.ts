import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { MentorSkills } from '../model/Mentor';

@Component({
  selector: 'app-trainings',
  templateUrl: './trainings.component.html',
  styleUrls: ['./trainings.component.css']
})
export class TrainingsComponent implements OnInit {
  mentorSkills: MentorSkills;

  constructor(private userService:UserService) { }

  ngOnInit() {
    this.userService.getMentorSkill()
    .subscribe(data => console.log(data), error => console.log(error));
    this.mentorSkills = new MentorSkills();
}
  }


